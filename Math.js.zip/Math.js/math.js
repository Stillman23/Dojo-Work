// function zero_negativity(arr) {
//     for (var i = 0; i < arr.length; i++) {
//         if (arr[i] < 0) {
//             return false;
//         }

//     }

//     return true;
// }

// array = [1,4,-3]
// console.log(zero_negativity(array));


// function is_even(num){
//     if (num % 2 == 0){
//         return true;
//     }
//     else{
//         return false;
//     }
// }
// console.log(is_even(44));



// function how_many_even(arr){
//     let counter = 0;
//     for(var k=0;k<arr.length;k++){
//         if(is_even(arr[k])){
//             counter += 1;
//         }
//     }
//     return counter;
// }
// array = [1, 4, -3, 6, 8, 10, 5, 12];
// console.log(how_many_even(array));


//Math 4
// function create_dummy_array(n){
//     let newArr = [];
//     for(var k=0;k<n;k++){
//         newArr.push(Math.floor(Math.random() * 10));
//     }
//     return newArr;
// }
// console.log(create_dummy_array(14));
//Math 5
// function random_choice(arr){
//     return arr[Math.floor(Math.random() * arr.length)];
// }
// array = [1, 4, -3, 6, 8, 10, 5, 12];
// console.log(random_choice(array));
<
/script> <
/body> <
/html>