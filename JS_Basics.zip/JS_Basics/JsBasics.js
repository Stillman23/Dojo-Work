< !DOCTYPE html >
    <
    html lang = "en" >
    <
    head >
    <
    meta charset = "UTF-8" >
    <
    meta name = "viewport"
content = "width=device-width, initial-scale=1.0" >
    <
    link rel = "stylesheet"
href = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
integrity = "sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
crossorigin = "anonymous" >
    <
    script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js" > < /script> <
title > TITLE < /title> < /
    head > <
    body >
    <
    h1 > HELLO WORLD < /h1> <
script >
    //Basic 1
    // let x = [];
    // x.push('coding');
    // x.push('dojo');
    // x.push('rocks');
    // for(var k=0;k<x.length;k++){
    //     x[k] = x[k+1];
    // }
    // x.pop();
    // console.log(x);

    //Basic 2
    // const y = []
    // console.log(y);
    // y.push(88);
    // console.log(y);
    //Basic 3
    // let z = [9, 10, 6, 5, -1, 20, 13, 2];
    // for(var k=0;k<z.length;k++){
    //     if(k == (z.length - 1)){
    //         break;
    //     }
    //     else{
    //         console.log(z[k]);
    //     }
    // }
    //Basic 4
    // let names = ['Kadie', 'Joe', 'Fritz', 'Pierre', 'Alphonso'];
    // for(var k=0;k<names.length;k++){
    //     for(var i=0;i<names[k].length;i++){
    //         if(names[k].length == 5){
    //             console.log(names[k][i]);
    //         }
    //         else{
    //             continue;
    //         }
    //     }
    // }
    //Basic 5
    // function yell(string){
    //     let newString = string.toUpperCase();
    //     console.log(newString);
    // }
    // yell('my name is erick!');
    <
    /script> < /
    body > <
    /html>